// import { optionHooksType, optionCommonType } from '@assi/common/lib/types'
// const { } = require('@assi/common/lib/types')
const hooks = {
  beforeIORead() {}
}

const alias = {
  '@medicine': 'src/medicine'
}

const plugins = []


module.exports  = {
  hooks,
  alias,
  plugins
}
