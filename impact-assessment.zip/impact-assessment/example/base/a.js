import { b } from './b.js';

export const aa = 'this is a.js';

console.log(b);