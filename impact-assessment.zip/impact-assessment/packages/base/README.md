# `base`

> TODO: description

## Usage

```
const base = require('base');

// TODO: DEMONSTRATE API
```
