import { optionType } from '@assi/common/lib/types';
export default class BaseClient {
    plugins: any;
    beDepChain: any;
    assessPath: string;
    ioStream: any;
    impactFile: any;
    option: optionType;
    constructor(assessPath: string, option: optionType);
    use(plugins: any[]): void;
    getDepStruct(pathList: string[]): Promise<unknown>;
    assessImpact(): Promise<void>;
}
