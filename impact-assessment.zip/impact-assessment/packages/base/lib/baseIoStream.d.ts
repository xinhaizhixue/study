export default class BaseIoStream {
    options: any;
    constructor(options: any);
    getCode(path: string): Promise<string>;
}
