import BaseClient from './baseClient.js';
import BaseIoStream from './baseIoStream.js';
declare function assessProcess(relAssiPath: string): Promise<void>;
export { BaseClient, BaseIoStream, assessProcess };
