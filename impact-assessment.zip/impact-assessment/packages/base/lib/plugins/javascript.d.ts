import { pluginType } from '@assi/common/lib/types';
declare const javaScriptPlugin: pluginType;
export default javaScriptPlugin;
