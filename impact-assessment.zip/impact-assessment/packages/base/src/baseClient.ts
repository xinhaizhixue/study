import _traverse from '@babel/traverse'
import * as _babel_types from '@babel/types';
import { utils } from '@assi/common';
import { optionType } from '@assi/common/lib/types'
import BaseIoStream from './baseIoStream.js';

const { pathHandle, gitHandle } = utils;

export default class BaseClient {
  plugins: any = {}
  beDepChain: any = {}
  assessPath: string = ''
  ioStream: any
  impactFile: any = {}
  option: optionType

  constructor(assessPath: string, option: optionType) {
    this.assessPath = assessPath;
    this.option = option;
    this.ioStream = new BaseIoStream({});
  }

  use(plugins: any[]) {
    plugins.forEach(plugin => {
      plugin.applyTo.forEach(ext => {
        this.plugins[ext] = plugin
      })
    })
  }

  getDepStruct(pathList: string[]) {
    return new Promise(async (res, rej) => {
      for (const path of pathList) {
        const ext = pathHandle.getExtname(path);
        const plugin = this.plugins[ext];
        if (!plugin) {
          continue
        }
        const code = await this.ioStream.getCode(path);
        const ast = plugin.astAnalysis(code);
        const depPathList = plugin.depAnalysis(ast, path);
        depPathList.forEach(depPath => {
          if (this.beDepChain[depPath]) {
            this.beDepChain[depPath].beDepPathList.push(depPath);
          } else {
            this.beDepChain[depPath] = {
              beDepPathList: [path]
            }
          }
        })
      }
      res('');
    })
  }

  async assessImpact() {
    const assessPathList = await pathHandle.getPathList(this.assessPath, process.cwd());
    await this.getDepStruct(assessPathList);
    const diffData = await gitHandle.getSummaryDiffForFile('main', 'dev');
    const diffFile = diffData.files;
    diffFile.forEach(file => {
      const filePath = pathHandle.getAbsPath(process.cwd(), file.file);
      this.impactFile[filePath] = this.beDepChain[filePath].beDepPathList
    })
    // 输出
    console.log(this.impactFile)
  }
}