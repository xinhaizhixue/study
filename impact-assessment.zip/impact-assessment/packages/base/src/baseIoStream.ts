import fs from 'fs';

const fsPromises = fs.promises;

export default class BaseIoStream {
  options
  constructor(options) {
    this.options = options;
  }

  // 获取path对应文件的代码内容
  async getCode(path: string): Promise<string> {
    console.log(path, 'path')
    const code = await fsPromises.readFile(path, { encoding: 'utf8' });
    return code.toString();
  }
}