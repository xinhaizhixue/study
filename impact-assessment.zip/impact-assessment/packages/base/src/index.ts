import { createRequire } from "module";
import { utils } from '@assi/common';
import { optionType } from '@assi/common/lib/types'
import BaseClient from './baseClient.js';
import BaseIoStream from './baseIoStream.js';
import javaScriptPlugin from './plugins/javaScript.js';

const require = createRequire(import.meta.url);
const { pathHandle, log } = utils;

function getOptionPath(projectPath: string): string | null {
  const { getAbsPath, isExists } = pathHandle;
  const optionPath = getAbsPath(projectPath, '.assi.js');
  if (isExists(optionPath)) {
    return optionPath;
  } else {
    return null;
  }
}

async function assessProcess(relAssiPath: string) {
  const { getAbsPath } = pathHandle;
  const projectPath = process.cwd();

  const assiPath = getAbsPath(projectPath, relAssiPath);
  const pkgPath = getAbsPath(projectPath, 'package.json');
  const optionPath = getOptionPath(projectPath);

  const thirdPartyLib: optionType['thirdPartyLib'] = []
  if (!pkgPath) {
    log.warningLog('项目不包含package.json文件，未能获取到项目三方依赖信息！');
  } else {
    const pkg = require(pkgPath);
    Object.keys(pkg.dependencies || {}).forEach(dependence => {
      thirdPartyLib.push(dependence);
    });
    Object.keys(pkg.devDependencies || {}).forEach(devDependence => {
      thirdPartyLib.push(devDependence);
    })
  }

  const option: optionType = { thirdPartyLib }
  if (!optionPath) {
    log.infoLog('项目未配置.assi.js/.assi.ts文件，将使用默认配置项。');
  } else {
    const configOption = require(optionPath);
    if (configOption.plugins) {
      configOption.plugins.push(javaScriptPlugin);
    } else {
      configOption.plugins = [javaScriptPlugin];
    }
    Object.assign(option, configOption);
  }
  const clientInstance = new BaseClient(assiPath, option);
  // clientInstance.use([javaScriptPlugin, ...plugins]);
  // clientInstance.assessImpact();
}

export { BaseClient, BaseIoStream, assessProcess }