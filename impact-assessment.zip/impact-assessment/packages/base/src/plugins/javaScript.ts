import { parse, ParseResult } from '@babel/parser';
import _traverse from '@babel/traverse'
import * as _babel_types from '@babel/types';
import { utils } from '@assi/common'
import { pluginType } from '@assi/common/lib/types'
import { pluginNameEnum, extensionEnum } from '@assi/common/lib/contants'

// @ts-ignore 忽略该行错误，该错误是babel官方的类型错误
const traverse = _traverse.default;

/**
 * name: 插件名
 * applyTo：该插件适用于哪些文件类型，例如js、ts、vue等
 * astAnalysis：插件分析ast的函数
 * depAnalysis：分析文件用到的依赖
 * beforMount：插件挂载前勾子
 * mounted：插件挂载后勾子
 */
const javaScriptPlugin: pluginType = {
  name: pluginNameEnum.JS_PLUGIN,
  applyTo: [extensionEnum.JS, extensionEnum.TS],
  astAnalysis(code: string) {
    const ast = parse(code, {
      plugins: [
        'jsx',
        'typescript',
        ['decorators', { allowCallParenthesized: true }],
        'decoratorAutoAccessors',
        'doExpressions',
        'exportDefaultFrom',
        'functionBind',
        'importAssertions',
        'regexpUnicodeSets'
      ],
      sourceType: 'unambiguous'
    });
    return ast;
  },
  depAnalysis(ast: ParseResult<_babel_types.File>, filePath: string) {
    const depPathList: string[] = [];
    traverse(ast, {
      ImportDeclaration ({ node }) {
        const relDepPath = node.source.value;
        const fileDir = utils.pathHandle.getDirname(filePath)
        const depPath = utils.pathHandle.getAbsPath(fileDir, relDepPath);
        console.log(depPath, 'depPath')
        depPathList.push(depPath);
      }
    })
    return depPathList;
  },
  beforeMount() {
    
  },
  mounted() {
    
  },
}

export default javaScriptPlugin