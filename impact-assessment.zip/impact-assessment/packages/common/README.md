# `common`

> TODO: description

## Usage

```
const common = require('common');

// TODO: DEMONSTRATE API
```
