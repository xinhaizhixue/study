'use strict';

const common = require('..');
const assert = require('assert').strict;

assert.strictEqual(common(), 'Hello from common');
console.info("common tests passed");
