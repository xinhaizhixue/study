export declare const enum pluginNameEnum {
    JS_PLUGIN = "jsPlugin"
}
export declare const enum extensionEnum {
    JS = "js",
    TS = "ts",
    VUE = "vue"
}
