export declare enum logTypeEnum {
    ERROR = "error",
    WARNING = "warning",
    INFO = "info",
    NORMAL = "normal"
}
