import { ParseResult } from '@babel/parser';
import * as _babel_types from '@babel/types';
import { pluginNameEnum, extensionEnum } from '../contants/index.js';
type pluginNameType = pluginNameEnum;
type extensionType = extensionEnum;
export interface pluginType<T extends pluginNameType = pluginNameType, C extends extensionType = extensionType> {
    name: T;
    applyTo: C[];
    astAnalysis: (code: string) => ParseResult<_babel_types.File>;
    depAnalysis: (ast: ParseResult<_babel_types.File>, filePath: string) => string[];
    beforeMount: () => void;
    mounted: () => void;
}
export {};
