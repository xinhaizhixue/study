import { logTypeEnum } from '../contants/util.js';
export type logMsg = object | string;
export type logType = logTypeEnum;
