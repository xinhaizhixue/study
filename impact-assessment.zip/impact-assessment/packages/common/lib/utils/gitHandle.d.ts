export declare function getCurrentBranch(): Promise<string>;
export declare function getDetailDiffForFile(branch1: string, branch2: string, filePath: string): Promise<{
    files: any;
    inBinaryDiff: boolean;
}>;
export declare function getSummaryDiffForFile(branch1: string, branch2: string): Promise<import("simple-git").DiffResult>;
