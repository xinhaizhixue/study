export * as log from './log.js';
export * as pathHandle from './pathHandle.js';
export * as gitHandle from './gitHandle.js';
declare const _default: {
    getCurrentBranch(): Promise<string>;
    getDetailDiffForFile(branch1: string, branch2: string, filePath: string): Promise<{
        files: any;
        inBinaryDiff: boolean;
    }>;
    getSummaryDiffForFile(branch1: string, branch2: string): Promise<import("simple-git").DiffResult>;
    getAbsPath(absBasePath: string, relativePath: string): string;
    getExtname(filePath: string): string;
    getDirname(filePath: string): string;
    isExists(filePath: string): boolean;
    isDirectory(filePath: string): Promise<boolean>;
    isFile(filePath: string): Promise<boolean>;
    getPathList(relAssessPath: string, basePath: string): Promise<string[]>;
    errorLog(msg: string | object): void;
    warningLog(msg: string | object): void;
    infoLog(msg: string | object): void;
    normalLog(msg: string | object): void;
};
export default _default;
