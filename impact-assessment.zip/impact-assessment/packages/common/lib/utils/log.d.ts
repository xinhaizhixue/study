export declare function errorLog(msg: object | string): void;
export declare function warningLog(msg: object | string): void;
export declare function infoLog(msg: object | string): void;
export declare function normalLog(msg: object | string): void;
