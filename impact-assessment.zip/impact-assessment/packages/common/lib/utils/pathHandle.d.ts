export declare function getAbsPath(absBasePath: string, relativePath: string): string;
export declare function getExtname(filePath: string): string;
export declare function getDirname(filePath: string): string;
export declare function isExists(filePath: string): boolean;
export declare function isDirectory(filePath: string): Promise<boolean>;
export declare function isFile(filePath: string): Promise<boolean>;
export declare function getPathList(relAssessPath: string, basePath: string): Promise<string[]>;
