export const enum pluginNameEnum {
  JS_PLUGIN = 'jsPlugin'
}

export const enum extensionEnum {
  JS = 'js',
  TS = 'ts',
  VUE = 'vue'
}