import { optionType } from './optionType';

export interface clientType {
  options: optionType,
  
}