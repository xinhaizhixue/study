import { pluginType } from './pluginType.js';

export interface optionHooksType {
  beforeIORead?: () => void,
  IORead?: () => void,
  beforeAllMount?: () => void,
  AllMounted?: () => void,
  beforeIOWtrite?: () => void,
  IOWrote?: () => void
}

export interface optionCommonType {
  alias?: { [propName: string]: string },
  pluginConfig?: any,
  plugins?: pluginType[]
}

type optionIntegrationType = optionHooksType & optionCommonType

export interface optionType extends optionIntegrationType{
  thirdPartyLib: string[]
}