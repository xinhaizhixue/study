import simpleGit from 'simple-git';

const git = simpleGit()

export async function getCurrentBranch () {
  const curBranch = await git.revparse(['--abbrev-ref', 'HEAD']);
  return curBranch;
}

export async function getDetailDiffForFile (branch1: string, branch2: string, filePath: string) {
  const diff = await git.diff([branch1, branch2, filePath]);
  const files: any = [];
  let currentFile: any = null;
  let currentHunk: any = null;
  let inBinaryDiff: boolean = false;

  // 分割文件内容到数组中
  const lines = diff.split(/\r?\n/);

  // 迭代每一行
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // 如果是二进制 diff，标记并跳过
    if (line.startsWith("Binary files ")) {
      inBinaryDiff = true;
      break;
    }

    // 解析文件头
    if (line.startsWith("diff --git ")) {
      if (currentFile) {
        files.push(currentFile);
      }

      // 获取文件名
      const filePaths = line.substring(11).split(" ");
      const oldPath = decodeURIComponent(filePaths[0].substring(2));
      const newPath = decodeURIComponent(filePaths[1].substring(2));
      
      currentFile = {
        oldPath,
        newPath,
        hunks: []
      };
      currentHunk = null;
    }

    // 解析块头
    if (line.startsWith("@@")) {
      const matches = /@@ -(\d+),(\d+) \+(\d+),(\d+) @@/.exec(line);
      if (matches) {
        const [_, oldStart, oldCount, newStart, newCount] = matches;
        currentHunk = {
          oldStart: parseInt(oldStart, 10),
          oldCount: parseInt(oldCount, 10),
          newStart: parseInt(newStart, 10),
          newCount: parseInt(newCount, 10),
          lines: []
        };
        
        currentFile.hunks.push(currentHunk);
      }
    }

    // 解析行内容
    if (line.startsWith(" ")) {
      if (currentHunk) {
        currentHunk.lines.push({
          type: " ",
          content: line.substr(1)
        });
      }
    } else if (line.startsWith("+")) {
      if (currentHunk) {
        currentHunk.lines.push({
          type: "+",
          content: line.substr(1)
        });
      }
    } else if (line.startsWith("-")) {
      if (currentHunk) {
        currentHunk.lines.push({
          type: "-",
          content: line.substr(1)
        });
      }
    }
  }

  if (currentFile) {
    files.push(currentFile);
  }

  return {
    files,
    inBinaryDiff
  };
}

export async function getSummaryDiffForFile(branch1: string, branch2: string) {
  const diff = await git.diffSummary([branch1, branch2]);
  return diff;
}
