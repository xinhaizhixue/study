import * as log from './log.js'
import * as pathHandle from './pathHandle.js';
import * as gitHandle from './gitHandle.js';

export * as log from './log.js'
export * as pathHandle from './pathHandle.js';
export * as gitHandle from './gitHandle.js';

export default { ...log, ...pathHandle, ...gitHandle };