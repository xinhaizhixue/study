// 打印错误信息，并终止进程
import chalk from 'chalk';
import { logType, logMsg } from '../types/utilType.js';
import { logTypeEnum } from '../contants/util.js'

const error = chalk.red;
const warning = chalk.yellow;
const info = chalk.green;
const normal = chalk.black;

function log(msg: logMsg, type: logType): void {
  msg = typeof msg === 'object' ? JSON.stringify(msg, null, 4) : msg
  switch (type) {
    case logTypeEnum.ERROR:
      console.log(error(`error : ${msg}`));
      process.exit(1);
    case logTypeEnum.WARNING:
      console.log(warning(`warning : ${msg}`))
      break;
    case logTypeEnum.INFO:
      console.log(info(`info : ${msg}`))
      break;
    default:
      console.log(normal(msg))
      break;
  }
}

export function errorLog (msg: object | string): void {
  log(msg, logTypeEnum.ERROR);
}

export function warningLog (msg: object | string): void {
  log(msg, logTypeEnum.WARNING);
}

export function infoLog (msg: object | string): void {
  log(msg, logTypeEnum.INFO);
}

export function normalLog (msg: object | string): void {
  log(msg, logTypeEnum.NORMAL);
}
