import fs from 'fs';
import path from 'path';
import { errorLog } from './log.js';

const fsPromises = fs.promises;

/**
 * 根据相对路径相对的绝对路径，获取相对路径所对应的绝对路径
 * @param absBasePath 相对路径相对的绝对路径
 * @param relativePath 待获取绝对路径的相对路径
 * @returns 返回相对路径的绝对路径
 */
export function getAbsPath (absBasePath: string, relativePath: string): string {
  if (path.isAbsolute(relativePath)) {
    return path.normalize(relativePath) // 当包含类似 .、.. 或 // 等相对的说明符时，就尝试计算实际的路径
  } else {
    return path.join(absBasePath, relativePath) // 将curPath和relativePath组合起来
  }
}

/**
 * 获取文件后缀
 * @param filePath 要获取文件后缀的绝对路径
 * @returns 返回文件后缀
 */
export function getExtname(filePath: string): string {
  return path.extname(filePath).slice(1)
}

/**
 * 获取文件目录
 * @param filePath 要获取文件目录的绝对路径
 * @returns 返回文件目录
 */
export function getDirname(filePath: string): string {
  return path.dirname(filePath);
}

/**
 * 判断文件是否存在
 * @param filePath 文件绝对路径
 * @returns 文件是否存在
 */
export function isExists(filePath: string): boolean {
  return fs.existsSync(filePath);
}

/**
 * 判断路径是否目录
 * @param filePath 绝对路径
 * @returns 是否目录
 */
export async function isDirectory(filePath: string): Promise<boolean> {
  if (!isExists(filePath)) {
    errorLog(`${filePath} 对应路径不存在！`)
  }
  const fileStats = await fsPromises.stat(filePath);
  return fileStats.isDirectory();
}

/**
 * 判断路径是否文件
 * @param filePath 绝对路径
 * @returns 是否文件
 */
export async function isFile(filePath: string): Promise<boolean> {
  if (!isExists(filePath)) {
    errorLog(`${filePath} 对应路径不存在！`)
  }
  const fileStats = await fsPromises.stat(filePath);
  return fileStats.isFile();
}

/**
 * 获取relAssessPath下所有文件的绝对路径
 * @param relAssessPath 需要进行影响评估的路径
 * @param basePath 当前仓库的绝对路径
 * @returns 返回评估路径下所有文件的绝对路径
 */
export async function getPathList(relAssessPath: string, basePath: string): Promise<string[]> {
  // 将需要评估的路径转换为绝对路径
  const assessPath: string = getAbsPath(basePath, relAssessPath);
  const pathList: string[] = [];
  const fileStats = await fsPromises.stat(assessPath);
  if (!fileStats.isDirectory()) {
    pathList.push(assessPath);
    return pathList;
  }

  // 获取assessPath下所有的文件路径
  const getFilePathDFS = async (absPath: string): Promise<void> => {
    const pathes: string[] = await fsPromises.readdir(absPath);
    for (let relPath of pathes) {
      const path = getAbsPath(absPath, relPath);
      const fileStats = await fsPromises.stat(path);
      if (fileStats.isDirectory()) {
        // 递归获取子目录下的文件路径
        getFilePathDFS(path);
      } else {
        pathList.push(path);
      }
    }
  }

  await getFilePathDFS(assessPath);
  return pathList;
}