import { pluginType, optionType } from '@assi/common/lib/types';
export declare abstract class CoreClient {
    options: optionType;
    constructor(options: optionType);
    use(plugins: pluginType[]): void;
    abstract isPluginEnable(): boolean;
    getOptions(): {};
}
