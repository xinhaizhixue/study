export declare abstract class coreIoStream {
    options: any;
    constructor(options: any);
    getPath(assessedPath: string, base?: string): string[];
    getCode(path: string): Promise<string>;
    getAst(code: string): void;
}
