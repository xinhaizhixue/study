import { pluginType, optionType } from '@assi/common/lib/types';

export abstract class CoreClient {
  options: optionType

  constructor(options: optionType) {
    this.options = options
  }

  // 挂载插件
  use(plugins: pluginType[]) {}

  abstract isPluginEnable(): boolean
  getOptions() {
    return {}
  }
}

