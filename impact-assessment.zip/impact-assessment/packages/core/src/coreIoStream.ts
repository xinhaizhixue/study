import path from "path";
import fs from "fs";

const fsPromises = fs.promises;
interface getPath {
  (assessedPath: string, base?: string): string[]
}
export abstract class coreIoStream {
  options
  constructor(options) {
    this.options = options;
  }

  // 获取assessedPath下所有文件的绝对路径
  getPath(assessedPath: string, base: string = this.options.base): string[] {
    // 将需要评估的路径转换为绝对路径
    let absAssessedPath: string = assessedPath;
    if (!path.isAbsolute(assessedPath)) {
      absAssessedPath = path.join(base, assessedPath);
    }
    const pathList: string[] = [];
    // 获取assessedPath下所有的文件路径
    const getFilePathDFS = async (absPath: string): Promise<void> => {
      const pathes: string[] = await fsPromises.readdir(absPath);
      for (let path of pathes) {
        const fileStats = await fsPromises.stat(path);
        if (fileStats.isDirectory()) {
          // 递归获取子目录下的文件路径
          getFilePathDFS(path);
        } else {
          pathList.push(path);
        }
      }
    }
    getFilePathDFS(absAssessedPath);
    return pathList;
  }

  // 获取path对应文件的代码内容
  async getCode(path: string): Promise<string> {
    const code = await fsPromises.readFile(path);
    return code.toString();
  }

  // 获取ast
  getAst(code: string) {
    
  }
}