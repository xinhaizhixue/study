'use strict';

const vue = require('..');
const assert = require('assert').strict;

assert.strictEqual(vue(), 'Hello from vue');
console.info("vue tests passed");
